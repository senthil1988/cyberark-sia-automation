#!/usr/bin/env python3
"""CSV-powered CyberArk SIA onboarding helper."""

from __future__ import annotations

import argparse
import csv
import json
import logging
import sys
from dataclasses import dataclass, field
from datetime import datetime
from getpass import getpass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from pydantic import BaseModel, Field, ValidationError, model_validator

from ark_sdk_python.auth import ArkISPAuth
from ark_sdk_python.common import ArkSystemConfig
from ark_sdk_python.models import ArkAuthException, ArkServiceException
from ark_sdk_python.models.auth import (
    ArkAuthMethod,
    ArkAuthProfile,
    ArkSecret,
    IdentityArkAuthMethodSettings,
)
from ark_sdk_python.models.common import ArkWorkspaceType
from ark_sdk_python.models.services.pcloud.accounts import ArkPCloudAccountsFilter
from ark_sdk_python.models.services.sia.policies.common.ark_sia_base_connection_information import ArkSIADaysOfWeek
from ark_sdk_python.models.services.sia.policies.common.ark_sia_rule_status import ArkSIARuleStatus
from ark_sdk_python.models.services.sia.policies.common.ark_sia_user_data import ArkSIAUserData
from ark_sdk_python.models.services.sia.policies.db import ArkSIADBAddPolicy
from ark_sdk_python.models.services.sia.policies.db.ark_sia_db_authorization_rule import (
    ArkSIADBAuthorizationRule,
    ArkSIADBConnectionInformation,
)
from ark_sdk_python.models.services.sia.policies.db.ark_sia_db_providers import ArkSIADBProvidersData
from ark_sdk_python.models.services.sia.policies.vm import ArkSIAVMAddPolicy
from ark_sdk_python.models.services.sia.policies.vm.ark_sia_vm_authorization_rule import (
    ArkSIAVMAuthorizationRule,
    ArkSIAVMConnectionInformation,
)
from ark_sdk_python.models.services.sia.policies.vm.ark_sia_vm_providers import ArkSIAVMProvidersDict
from ark_sdk_python.models.services.sia.secrets.db import (
    ArkSIADBAddSecret,
    ArkSIADBDeleteSecret,
    ArkSIADBGetSecret,
    ArkSIADBSecretsFilter,
    ArkSIADBSecretType,
    ArkSIADBStoreType,
)
from ark_sdk_python.models.services.sia.secrets.vm import (
    ArkSIAVMAddSecret,
    ArkSIAVMDeleteSecret,
    ArkSIAVMGetSecret,
    ArkSIAVMSecretType,
    ArkSIAVMSecretsFilter,
)
from ark_sdk_python.models.services.sia.workspaces.db import (
    ArkSIADBAddDatabase,
    ArkSIADBAuthMethodType,
    ArkSIADBDatabaseEngineType,
    ArkSIADBDatabaseTargetService,
    ArkSIADBDeleteDatabase,
    ArkSIADBDatabasesFilter,
    ArkSIADBTag,
)
from ark_sdk_python.models.services.sia.workspaces.targetsets import (
    ArkSIAAddTargetSet,
    ArkSIADeleteTargetSet,
    ArkSIATargetSetType,
    ArkSIATargetSetsFilter,
)
from ark_sdk_python.services.pcloud import ArkPCloudAPI
from ark_sdk_python.services.sia import ArkSIAAPI

LOGGER = logging.getLogger("sia_onboarding")
SUPPORTED_MFA_METHODS: List[str] = ["pf", "sms", "email", "otp", "oath", "auto"]

DAY_ALIAS_MAP: Dict[str, str] = {}
for _day in ArkSIADaysOfWeek:
    DAY_ALIAS_MAP[_day.value.lower()] = _day.value
    DAY_ALIAS_MAP[_day.name.lower()] = _day.value

OPERATION_DESCRIPTIONS: Dict[str, str] = {
    "onboard_db": "Onboard SIA database strong accounts & workspaces",
    "onboard_vm": "Onboard SIA Windows/Unix VM strong accounts & target sets",
    "onboard_both": "Onboard both database and VM strong accounts",
    "policy": "Create SIA access policies",
    "policy_db": "Create SIA database access policies",
    "policy_vm": "Create SIA VM access policies",
    "delete_secrets": "Delete SIA strong accounts",
    "delete_workspaces": "Delete SIA workspaces",
    "delete_db_workspaces": "Delete SIA database workspaces",
    "delete_vm_workspaces": "Delete SIA VM target sets",
    "delete_db_secrets": "Delete SIA database strong accounts",
    "delete_vm_secrets": "Delete SIA VM strong accounts",
}

OPERATION_MENU_ORDER: List[str] = [
    "onboard_db",
    "onboard_vm",
    "onboard_both",
    "policy",
    "delete_secrets",
    "delete_workspaces",
]

PRIMARY_OPERATION_ALIAS: Dict[str, str] = {
    "onboard_db": "db",
    "onboard_vm": "vm",
    "onboard_both": "db+vm",
    "policy": "policy",
    "policy_db": "db-policy",
    "policy_vm": "vm-policy",
    "delete_secrets": "delete-secrets",
    "delete_workspaces": "delete-workspaces",
    "delete_db_workspaces": "db-delete",
    "delete_vm_workspaces": "vm-delete",
    "delete_db_secrets": "db-strong-delete",
    "delete_vm_secrets": "vm-strong-delete",
}

OPERATION_ALIASES: Dict[str, str] = {
    "db": "onboard_db",
    "database": "onboard_db",
    "vm": "onboard_vm",
    "vm-strong": "onboard_vm",
    "vm-targets": "onboard_vm",
    "db+vm": "onboard_both",
    "both": "onboard_both",
    "all": "onboard_both",
    "policy": "policy",
    "policies": "policy",
    "db-policy": "policy_db",
    "vm-policy": "policy_vm",
    "delete-secrets": "delete_secrets",
    "delete-strong": "delete_secrets",
    "delete-workspaces": "delete_workspaces",
    "delete-workspace": "delete_workspaces",
    "db-delete": "delete_db_workspaces",
    "vm-delete": "delete_vm_workspaces",
    "db-strong-delete": "delete_db_secrets",
    "vm-strong-delete": "delete_vm_secrets",
}

TEMPLATE_FLAG_HINTS: Dict[str, str] = {
    "DB onboarding template path": "-d/--db-template <path>",
    "VM onboarding template path": "-v/--vm-template <path>",
    "DB access policy template path": "-p/--db-policy-template <path>",
    "VM access policy template path": "-q/--vm-policy-template <path>",
}

TEMPLATE_MESSAGE_TO_ATTR: Dict[str, str] = {
    "DB onboarding template path": "db_template",
    "VM onboarding template path": "vm_template",
    "DB access policy template path": "db_policy_template",
    "VM access policy template path": "vm_policy_template",
}

ACTION_TEMPLATE_REQUIREMENTS: Dict[str, List[str]] = {
    "onboard_db": ["DB onboarding template path"],
    "onboard_vm": ["VM onboarding template path"],
    "onboard_both": ["DB onboarding template path", "VM onboarding template path"],
    "policy": ["DB access policy template path", "VM access policy template path"],
    "policy_db": ["DB access policy template path"],
    "policy_vm": ["VM access policy template path"],
}

def print_operation_summary() -> None:
    print("\nAvailable operations:")
    for canonical in OPERATION_MENU_ORDER:
        description = OPERATION_DESCRIPTIONS.get(canonical, canonical)
        aliases = sorted(alias for alias, target in OPERATION_ALIASES.items() if target == canonical)
        primary = PRIMARY_OPERATION_ALIAS.get(canonical, aliases[0] if aliases else canonical)
        remaining = [alias for alias in aliases if alias != primary]
        alias_display = f"{primary}" if not remaining else f"{primary} (also: {', '.join(remaining)})"
        print(
            "  {alias:<25} - {description}".format(
                alias=alias_display,
                description=description,
            )
        )
    print()


def print_template_hints(messages: Optional[Iterable[str]] = None) -> None:
    required = list(messages) if messages is not None else list(TEMPLATE_FLAG_HINTS)
    if not required:
        return
    print("Template flags:")
    for message in required:
        hint = TEMPLATE_FLAG_HINTS.get(message, "the appropriate template flag")
        print(f"  {message}: use {hint}")
    print()


def prompt_operation_choice() -> str:
    if not sys.stdin.isatty():
        raise SystemExit("No operation provided and interactive input is unavailable.")
    print("Select an operation:")
    for idx, canonical in enumerate(OPERATION_MENU_ORDER, start=1):
        aliases = sorted(alias for alias, target in OPERATION_ALIASES.items() if target == canonical)
        alias_display = ", ".join(aliases)
        description = OPERATION_DESCRIPTIONS.get(canonical, "")
        print(f"  {idx}. {description} [{alias_display}]")
    print()
    while True:
        choice = strip_value(input("Enter number or alias: "))
        if choice is None:
            print("  Please enter a number from the list or an operation alias.")
            continue
        if choice.isdigit():
            index = int(choice)
            if 1 <= index <= len(OPERATION_MENU_ORDER):
                return OPERATION_MENU_ORDER[index - 1]
            print(f"  Choose a number between 1 and {len(OPERATION_MENU_ORDER)}.")
            continue
        alias = choice.lower()
        if alias in OPERATION_ALIASES:
            return OPERATION_ALIASES[alias]
        print("  Unknown selection. Enter a valid number or alias.")


def validate_template_args(args: argparse.Namespace, action: str) -> None:
    if action in {
        "delete_workspaces",
        "delete_db_workspaces",
        "delete_vm_workspaces",
        "delete_db_secrets",
        "delete_vm_secrets",
    }:
        return
    messages = ACTION_TEMPLATE_REQUIREMENTS.get(action, [])
    missing: List[str] = []
    for message in messages:
        attr = TEMPLATE_MESSAGE_TO_ATTR.get(message)
        if not attr:
            continue
        value: Optional[Path] = getattr(args, attr, None)
        if value is None:
            continue
        if not value.exists():
            missing.append(f"'{value}' for {message}")
    if missing:
        print_template_hints()
        raise SystemExit("Missing template file(s): %s" % ", ".join(missing))


def prompt_scoped_operation(base_action: str) -> str:
    if base_action not in {"onboard_db", "onboard_vm"}:
        return base_action

    options: List[Tuple[str, str]]
    if base_action == "onboard_db":
        options = [
            ("onboard_db", OPERATION_DESCRIPTIONS["onboard_db"]),
            ("delete_db_workspaces", OPERATION_DESCRIPTIONS["delete_db_workspaces"]),
            ("delete_db_secrets", OPERATION_DESCRIPTIONS["delete_db_secrets"]),
            ("policy_db", OPERATION_DESCRIPTIONS["policy_db"]),
        ]
        prompt_label = "Select database operation"
    else:
        options = [
            ("onboard_vm", OPERATION_DESCRIPTIONS["onboard_vm"]),
            ("delete_vm_workspaces", OPERATION_DESCRIPTIONS["delete_vm_workspaces"]),
            ("delete_vm_secrets", OPERATION_DESCRIPTIONS["delete_vm_secrets"]),
            ("policy_vm", OPERATION_DESCRIPTIONS["policy_vm"]),
        ]
        prompt_label = "Select VM operation"

    print(f"\n{prompt_label}:")
    for idx, (_, description) in enumerate(options, start=1):
        print(f"  {idx}. {description}")

    while True:
        choice = strip_value(input("Enter number: "))
        if choice is None:
            default_action = options[0][0]
            show_action_hints(default_action)
            return default_action
        if choice and choice.isdigit():
            index = int(choice)
            if 1 <= index <= len(options):
                selected_action = options[index - 1][0]
                show_action_hints(selected_action)
                return selected_action
            print(f"  Choose a number between 1 and {len(options)}.")
            continue
        print("  Please enter a number from the list.")


def show_action_hints(action: str) -> None:
    messages = ACTION_TEMPLATE_REQUIREMENTS.get(action)
    if not messages:
        return
    print("Required flags for this operation:")
    for message in messages:
        hint = TEMPLATE_FLAG_HINTS.get(message, message)
        print(f"  {message}: use {hint}")
    print()



class TagConfig(BaseModel):
    key: str
    value: str


class DomainControllerConfig(BaseModel):
    name: Optional[str] = None
    netbios: Optional[str] = None
    use_ldaps: Optional[bool] = None
    enable_certificate_validation: Optional[bool] = None
    ldaps_certificate: Optional[str] = None


class DatabaseServiceConfig(BaseModel):
    service_name: str = Field(description="Friendly service identifier inside the database")
    port: Optional[int] = Field(default=None, ge=1, le=65535)
    secret_ref: Optional[str] = Field(default=None, description="Alias of a DB secret defined in the template")
    secret_id: Optional[str] = Field(default=None, description="Explicit secret identifier override")


class DbSecretConfig(BaseModel):
    alias: str = Field(description="In-template identifier used by databases")
    secret_name: str = Field(description="Name that will be visible inside SIA")
    description: str = Field(default="", description="Secret description")
    purpose: str = Field(default="", description="Purpose of the secret")
    secret_type: ArkSIADBSecretType
    store_type: Optional[ArkSIADBStoreType] = Field(default=None)
    tags: List[TagConfig] = Field(default_factory=list)

    username: Optional[str] = None
    password: Optional[str] = None
    pam_safe: Optional[str] = None
    pam_account_name: Optional[str] = None
    iam_account: Optional[str] = None
    iam_username: Optional[str] = None
    iam_access_key_id: Optional[str] = None
    iam_secret_access_key: Optional[str] = None
    atlas_public_key: Optional[str] = None
    atlas_private_key: Optional[str] = None

    def to_model(self) -> ArkSIADBAddSecret:
        return ArkSIADBAddSecret(
            secret_name=self.secret_name,
            description=self.description,
            purpose=self.purpose,
            secret_type=self.secret_type,
            store_type=self.store_type,
            tags=[ArkSIADBTag(key=t.key, value=t.value) for t in self.tags],
            username=self.username,
            password=self.password,
            pam_safe=self.pam_safe,
            pam_account_name=self.pam_account_name,
            iam_account=self.iam_account,
            iam_username=self.iam_username,
            iam_access_key_id=self.iam_access_key_id,
            iam_secret_access_key=self.iam_secret_access_key,
            atlas_public_key=self.atlas_public_key,
            atlas_private_key=self.atlas_private_key,
        )


class VmSecretConfig(BaseModel):
    alias: str = Field(description="In-template identifier used by VM target sets")
    secret_type: ArkSIAVMSecretType
    secret_name: Optional[str] = Field(default=None)
    secret_details: Dict[str, Any] = Field(default_factory=dict)
    is_disabled: bool = Field(default=False)
    provisioner_username: Optional[str] = None
    provisioner_password: Optional[str] = None
    pcloud_account_safe: Optional[str] = None
    pcloud_account_name: Optional[str] = None

    def to_model(self) -> ArkSIAVMAddSecret:
        return ArkSIAVMAddSecret(
            secret_name=self.secret_name,
            secret_details=self.secret_details or None,
            secret_type=self.secret_type,
            is_disabled=self.is_disabled,
            provisioner_username=self.provisioner_username,
            provisioner_password=self.provisioner_password,
            pcloud_account_safe=self.pcloud_account_safe,
            pcloud_account_name=self.pcloud_account_name,
        )

    @model_validator(mode="after")
    def _validate_secret_requirements(cls, model: "VmSecretConfig") -> "VmSecretConfig":
        if model.secret_type == ArkSIAVMSecretType.PCloudAccount:
            if not model.pcloud_account_safe or not model.pcloud_account_name:
                raise ValueError(
                    f"VM secret alias '{model.alias}' requires both pcloud_account_safe and pcloud_account_name when secret_type is PCloudAccount."
                )
        elif model.secret_type == ArkSIAVMSecretType.ProvisionerUser:
            if not model.provisioner_username or not model.provisioner_password:
                raise ValueError(
                    f"VM secret alias '{model.alias}' requires both provisioner_username and provisioner_password when secret_type is ProvisionerUser."
                )
        return model


class DatabaseConfig(BaseModel):
    name: str
    provider_engine: ArkSIADBDatabaseEngineType
    platform: ArkWorkspaceType = Field(default=ArkWorkspaceType.ONPREM)
    network_name: str = Field(default="ON-PREMISE")
    auth_database: str = Field(default="admin")
    read_write_endpoint: Optional[str] = None
    read_only_endpoint: Optional[str] = None
    region: Optional[str] = None
    secret_ref: Optional[str] = Field(default=None, description="Alias of a DB secret defined in the template")
    secret_id: Optional[str] = Field(default=None, description="Explicit secret identifier override")
    enable_certificate_validation: Optional[bool] = Field(default=True)
    domain: Optional[str] = None
    domain_controller: Optional[DomainControllerConfig] = None
    services: List[DatabaseServiceConfig] = Field(default_factory=list)
    tags: List[TagConfig] = Field(default_factory=list)
    configured_auth_method_type: Optional[ArkSIADBAuthMethodType] = None
    account: Optional[str] = None


class VmTargetSetConfig(BaseModel):
    name: str
    type: ArkSIATargetSetType = Field(default=ArkSIATargetSetType.DOMAIN)
    description: Optional[str] = None
    provision_format: Optional[str] = None
    enable_certificate_validation: Optional[bool] = None
    secret_type: Optional[ArkSIAVMSecretType] = None
    secret_ref: Optional[str] = Field(default=None, description="Alias of a VM secret defined in the template")
    secret_id: Optional[str] = Field(default=None, description="Explicit secret identifier override")


@dataclass
class DbTemplateData:
    database_secrets: List[DbSecretConfig] = field(default_factory=list)
    databases: List[DatabaseConfig] = field(default_factory=list)


@dataclass
class VmTemplateData:
    vm_secrets: List[VmSecretConfig] = field(default_factory=list)
    vm_target_sets: List[VmTargetSetConfig] = field(default_factory=list)


@dataclass
class DbPolicyConfig:
    policy_name: str
    description: Optional[str]
    status: ArkSIARuleStatus
    start_date: Optional[str]
    end_date: Optional[str]
    providers_tags: List[str]
    providers_data: Dict[str, Any]
    rule_name: str
    user_roles: List[str]
    user_groups: List[str]
    user_users: List[str]
    full_days: Optional[bool]
    days_of_week: List[str]
    hours_from: Optional[str]
    hours_to: Optional[str]
    time_zone: Optional[str]
    grant_access_hours: Optional[int]
    idle_time_minutes: Optional[int]
    connect_as: Dict[str, Any]
    line_number: int


@dataclass
class VmPolicyConfig:
    policy_name: str
    description: Optional[str]
    status: ArkSIARuleStatus
    start_date: Optional[str]
    end_date: Optional[str]
    providers_data: Dict[str, Any]
    rule_name: str
    user_roles: List[str]
    user_groups: List[str]
    user_users: List[str]
    full_days: Optional[bool]
    days_of_week: List[str]
    hours_from: Optional[str]
    hours_to: Optional[str]
    time_zone: Optional[str]
    grant_access_hours: Optional[int]
    idle_time_minutes: Optional[int]
    connect_as: Dict[str, Any]
    line_number: int

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="CyberArk SIA helper for onboarding workspaces and access policies.",
    )
    operation_choices = sorted(OPERATION_ALIASES.keys())
    parser.add_argument(
        "operation",
        choices=operation_choices,
        help="Operation to perform (see epilog).",
    )
    parser.add_argument(
        "-d", "--db-template",
        type=Path,
        default=None,
        help="Path to the database onboarding template CSV file (required for db/db+vm operations).",
    )
    parser.add_argument(
        "-v", "--vm-template",
        type=Path,
        default=None,
        help="Path to the VM onboarding template CSV file (required for vm/db+vm operations).",
    )
    parser.add_argument(
        "-p", "--db-policy-template",
        type=Path,
        default=None,
        help="Path to the DB access policy template CSV file (required when processing DB policies).",
    )
    parser.add_argument(
        "-q", "--vm-policy-template",
        type=Path,
        default=None,
        help="Path to the VM access policy template CSV file (required when processing VM policies).",
    )
    parser.add_argument(
        "--log-dir",
        type=Path,
        default=Path("logs"),
        help="Directory where execution logs should be written.",
    )
    epilog_lines = ["Available operations (alias -> description):"]
    for alias in operation_choices:
        canonical = OPERATION_ALIASES[alias]
        epilog_lines.append(f"  {alias:<15} -> {OPERATION_DESCRIPTIONS[canonical]}")
    epilog_lines.append("")
    epilog_lines.append("Example: python3 sia_onboarding.py db -d path/to/db_template.csv")
    parser.epilog = "\n".join(epilog_lines)
    if len(sys.argv) <= 1:
        parser.print_usage(sys.stderr)
        print_operation_summary()
        raise SystemExit("Operation argument is required. Pass one of the listed options.")
    return parser.parse_args()

def strip_value(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    text = value.strip()
    return text or None


def parse_bool(value: Optional[str]) -> Optional[bool]:
    text = strip_value(value)
    if text is None:
        return None
    truthy = {"true", "yes", "y", "1"}
    falsy = {"false", "no", "n", "0"}
    lowered = text.lower()
    if lowered in truthy:
        return True
    if lowered in falsy:
        return False
    raise ValueError(f"Unable to parse boolean value '{value}'")


def parse_list(value: Optional[str]) -> List[str]:
    text = strip_value(value)
    if not text:
        return []
    normalized = text.replace(";", ",")
    return [item.strip() for item in normalized.split(",") if item and item.strip()]


def parse_days_of_week(value: Optional[str], line_no: int, column: str = "days_of_week") -> List[str]:
    entries = parse_list(value)
    days: List[str] = []
    for entry in entries:
        key = entry.lower()
        if key not in DAY_ALIAS_MAP:
            valid_values = ", ".join(sorted({v for v in DAY_ALIAS_MAP.values()}))
            raise ValueError(f"Row {line_no}: column '{column}' contains invalid day '{entry}'. Expected one of: {valid_values}")
        days.append(DAY_ALIAS_MAP[key])
    return days


def parse_int(value: Optional[str], column: str, line_no: int) -> Optional[int]:
    text = strip_value(value)
    if text is None:
        return None
    try:
        return int(text)
    except ValueError as exc:
        raise ValueError(f"Row {line_no}: column '{column}' must be an integer.") from exc


def parse_rule_status(value: Optional[str], line_no: int, column: str = "status") -> ArkSIARuleStatus:
    if not value:
        return ArkSIARuleStatus.Enabled
    text = value.strip().lower()
    for status in ArkSIARuleStatus:
        if status.value.lower() == text or status.name.lower() == text:
            return status
    allowed = ", ".join([status.value for status in ArkSIARuleStatus])
    raise ValueError(f"Row {line_no}: column '{column}' must be one of {allowed}.")


def parse_json_required(value: Optional[str], column: str, line_no: int) -> Dict[str, Any]:
    data = parse_json_object(value)
    if not data:
        raise ValueError(f"Row {line_no}: column '{column}' must contain a JSON object.")
    return data


def compact_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    compacted: Dict[str, Any] = {}
    for key, value in data.items():
        if value is None:
            continue
        if isinstance(value, list) and len(value) == 0:
            continue
        if isinstance(value, dict) and len(value) == 0:
            continue
        compacted[key] = value
    return compacted


def parse_tags(value: Optional[str]) -> List[TagConfig]:
    text = strip_value(value)
    if not text:
        return []
    tags: List[TagConfig] = []
    for chunk in text.split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" not in chunk:
            raise ValueError(f"Tag '{chunk}' must be in key=value format")
        key, val = chunk.split("=", 1)
        tags.append(TagConfig(key=key.strip(), value=val.strip()))
    return tags


def parse_services(value: Optional[str]) -> List[DatabaseServiceConfig]:
    text = strip_value(value)
    if not text:
        return []
    services: List[DatabaseServiceConfig] = []
    for chunk in text.split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        parts = [part.strip() or None for part in chunk.split(":")]
        if not parts[0]:
            raise ValueError(f"Service descriptor '{chunk}' is missing a service name")
        port: Optional[int] = None
        if len(parts) > 1 and parts[1]:
            try:
                port = int(parts[1])
            except ValueError as exc:
                raise ValueError(f"Service descriptor '{chunk}' has an invalid port") from exc
        secret_alias = parts[2] if len(parts) > 2 else None
        secret_id = parts[3] if len(parts) > 3 else None
        services.append(
            DatabaseServiceConfig(service_name=parts[0], port=port, secret_ref=secret_alias, secret_id=secret_id)
        )
    return services


def parse_json_object(value: Optional[str]) -> Dict[str, Any]:
    text = strip_value(value)
    if not text:
        return {}
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON payload '{value}'") from exc
    if not isinstance(parsed, dict):
        raise ValueError("JSON payload must represent an object")
    return parsed


def require_value(row: Dict[str, str], column: str, line_no: int) -> str:
    value = strip_value(row.get(column))
    if value is None:
        raise ValueError(f"Row {line_no}: column '{column}' is required")
    return value


def load_db_template_csv(path: Path) -> DbTemplateData:
    if not path.exists():
        raise FileNotFoundError(f"DB onboarding template file '{path}' does not exist")
    template = DbTemplateData()
    db_aliases: set[str] = set()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "record_type" not in reader.fieldnames:
            raise ValueError("The DB onboarding CSV must include a 'record_type' header column.")
        for index, row in enumerate(reader, start=2):  # account for header
            if not row:
                continue
            record_type = strip_value(row.get("record_type"))
            if not record_type:
                continue
            try:
                record_key = record_type.lower()
                if record_key == "db_secret":
                    alias = strip_value(row.get("alias")) or strip_value(row.get("secret_name"))
                    if not alias:
                        raise ValueError(f"Row {index}: either 'alias' or 'secret_name' must be provided for db_secret entries.")
                    if alias in db_aliases:
                        raise ValueError(f"Row {index}: duplicate DB secret alias '{alias}'")
                    secret = DbSecretConfig(
                        alias=alias,
                        secret_name=require_value(row, "secret_name", index),
                        description=strip_value(row.get("description")) or "",
                        purpose=strip_value(row.get("purpose")) or "",
                        secret_type=require_value(row, "secret_type", index),
                        store_type=strip_value(row.get("store_type")),
                        username=strip_value(row.get("username")),
                        password=strip_value(row.get("password")),
                        pam_safe=strip_value(row.get("pam_safe")),
                        pam_account_name=strip_value(row.get("pam_account_name")),
                        iam_account=strip_value(row.get("iam_account")),
                        iam_username=strip_value(row.get("iam_username")),
                        iam_access_key_id=strip_value(row.get("iam_access_key_id")),
                        iam_secret_access_key=strip_value(row.get("iam_secret_access_key")),
                        atlas_public_key=strip_value(row.get("atlas_public_key")),
                        atlas_private_key=strip_value(row.get("atlas_private_key")),
                        tags=parse_tags(row.get("tags")),
                    )
                    template.database_secrets.append(secret)
                    db_aliases.add(alias)
                elif record_key == "database":
                    domain_controller = DomainControllerConfig(
                        name=strip_value(row.get("domain_controller_name")),
                        netbios=strip_value(row.get("domain_controller_netbios")),
                        use_ldaps=parse_bool(row.get("domain_controller_use_ldaps")),
                        enable_certificate_validation=parse_bool(row.get("domain_controller_enable_certificate_validation")),
                        ldaps_certificate=strip_value(row.get("domain_controller_ldaps_certificate")),
                    )
                    if all(value is None for value in domain_controller.model_dump().values()):
                        domain_controller = None
                    secret_alias = strip_value(row.get("secret_alias"))
                    inline_secret_name = strip_value(row.get("secret_name"))
                    inline_secret_type = strip_value(row.get("secret_type"))
                    if not secret_alias and inline_secret_name and inline_secret_type:
                        generated_alias = strip_value(row.get("alias")) or f"auto_db_secret_{len(db_aliases) + 1}"
                        if generated_alias in db_aliases:
                            raise ValueError(f"Row {index}: inline DB secret alias '{generated_alias}' duplicates an existing alias")
                        inline_secret = DbSecretConfig(
                            alias=generated_alias,
                            secret_name=inline_secret_name,
                            description=strip_value(row.get("description")) or "",
                            purpose=strip_value(row.get("purpose")) or "",
                            secret_type=inline_secret_type,
                            store_type=strip_value(row.get("store_type")),
                            username=strip_value(row.get("username")),
                            password=strip_value(row.get("password")),
                            pam_safe=strip_value(row.get("pam_safe")),
                            pam_account_name=strip_value(row.get("pam_account_name")),
                            iam_account=strip_value(row.get("iam_account")),
                            iam_username=strip_value(row.get("iam_username")),
                            iam_access_key_id=strip_value(row.get("iam_access_key_id")),
                            iam_secret_access_key=strip_value(row.get("iam_secret_access_key")),
                            atlas_public_key=strip_value(row.get("atlas_public_key")),
                            atlas_private_key=strip_value(row.get("atlas_private_key")),
                            tags=parse_tags(row.get("tags")),
                        )
                        template.database_secrets.append(inline_secret)
                        db_aliases.add(generated_alias)
                        secret_alias = generated_alias
                    db_config = DatabaseConfig(
                        name=require_value(row, "name", index),
                        provider_engine=require_value(row, "provider_engine", index),
                        platform=strip_value(row.get("platform")) or ArkWorkspaceType.ONPREM,
                        network_name=strip_value(row.get("network_name")) or "ON-PREMISE",
                        auth_database=strip_value(row.get("auth_database")) or "admin",
                        read_write_endpoint=strip_value(row.get("read_write_endpoint")),
                        read_only_endpoint=strip_value(row.get("read_only_endpoint")),
                        region=strip_value(row.get("region")),
                        secret_ref=secret_alias,
                        secret_id=strip_value(row.get("secret_id")),
                        enable_certificate_validation=parse_bool(row.get("enable_certificate_validation")),
                        domain=strip_value(row.get("domain")),
                        domain_controller=domain_controller,
                        services=parse_services(row.get("services")),
                        tags=parse_tags(row.get("tags")),
                        configured_auth_method_type=strip_value(row.get("configured_auth_method_type")),
                        account=strip_value(row.get("account")),
                    )
                    template.databases.append(db_config)
                else:
                    raise ValueError(f"Row {index}: unsupported record_type '{record_type}'")
            except (ValidationError, ValueError) as exc:
                raise ValueError(f"Error while parsing row {index}: {exc}") from exc
    if not template.database_secrets and not template.databases:
        raise ValueError("DB onboarding template did not contain any db_secret or database records.")
    return template


def load_vm_template_csv(path: Path) -> VmTemplateData:
    if not path.exists():
        raise FileNotFoundError(f"VM onboarding template file '{path}' does not exist")
    template = VmTemplateData()
    vm_aliases: set[str] = set()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "record_type" not in reader.fieldnames:
            raise ValueError("The VM onboarding CSV must include a 'record_type' header column.")
        for index, row in enumerate(reader, start=2):
            if not row:
                continue
            record_type = strip_value(row.get("record_type"))
            if not record_type:
                continue
            try:
                record_key = record_type.lower()
                if record_key == "vm_secret":
                    alias = strip_value(row.get("alias")) or strip_value(row.get("secret_name"))
                    if not alias:
                        raise ValueError(f"Row {index}: either 'alias' or 'secret_name' must be provided for vm_secret entries.")
                    if alias in vm_aliases:
                        raise ValueError(f"Row {index}: duplicate VM secret alias '{alias}'")
                    secret = VmSecretConfig(
                        alias=alias,
                        secret_type=require_value(row, "secret_type", index),
                        secret_name=strip_value(row.get("secret_name")),
                        secret_details=parse_json_object(row.get("secret_details")),
                        provisioner_username=strip_value(row.get("provisioner_username")),
                        provisioner_password=strip_value(row.get("provisioner_password")),
                        pcloud_account_safe=strip_value(row.get("pcloud_account_safe")),
                        pcloud_account_name=strip_value(row.get("pcloud_account_name")),
                        is_disabled=parse_bool(row.get("is_disabled")) or False,
                    )
                    template.vm_secrets.append(secret)
                    vm_aliases.add(alias)
                elif record_key == "vm_target_set":
                    target_set = VmTargetSetConfig(
                        name=require_value(row, "name", index),
                        type=strip_value(row.get("target_set_type")) or ArkSIATargetSetType.DOMAIN,
                        description=strip_value(row.get("description")),
                        provision_format=strip_value(row.get("provision_format")),
                        enable_certificate_validation=parse_bool(row.get("enable_certificate_validation")),
                        secret_type=strip_value(row.get("secret_type")),
                        secret_ref=strip_value(row.get("secret_alias")),
                        secret_id=strip_value(row.get("secret_id")),
                    )
                    if not target_set.secret_ref:
                        inline_secret_name = strip_value(row.get("secret_name"))
                        inline_secret_type = strip_value(row.get("secret_type"))
                        if inline_secret_name and inline_secret_type:
                            generated_alias = strip_value(row.get("alias")) or f"auto_vm_secret_{len(vm_aliases) + 1}"
                            if generated_alias in vm_aliases:
                                raise ValueError(f"Row {index}: inline VM secret alias '{generated_alias}' duplicates an existing alias")
                            inline_secret = VmSecretConfig(
                                alias=generated_alias,
                                secret_type=inline_secret_type,
                                secret_name=inline_secret_name,
                                secret_details=parse_json_object(row.get("secret_details")),
                                provisioner_username=strip_value(row.get("provisioner_username")),
                                provisioner_password=strip_value(row.get("provisioner_password")),
                                pcloud_account_safe=strip_value(row.get("pcloud_account_safe")),
                                pcloud_account_name=strip_value(row.get("pcloud_account_name")),
                                is_disabled=parse_bool(row.get("is_disabled")) or False,
                            )
                            template.vm_secrets.append(inline_secret)
                            vm_aliases.add(generated_alias)
                            target_set.secret_ref = generated_alias
                    template.vm_target_sets.append(target_set)
                else:
                    raise ValueError(f"Row {index}: unsupported record_type '{record_type}'")
            except (ValidationError, ValueError) as exc:
                raise ValueError(f"Error while parsing row {index}: {exc}") from exc
    if not template.vm_secrets and not template.vm_target_sets:
        raise ValueError("VM onboarding template did not contain any vm_secret or vm_target_set records.")
    return template


def prompt_identity_inputs() -> Dict[str, Any]:
    print("\nIdentity authentication")
    print("-----------------------")
    username = ""
    while not username:
        username = strip_value(input("Identity username: "))
        if not username:
            print("  Username is required.")
    password = ""
    while not password:
        password = getpass("Identity password: ")
        if not password:
            print("  Password is required.")
    mfa_method = prompt_mfa_method()
    interactive = prompt_yes_no("Enable interactive MFA prompts (passcodes/device approvals)?", default=True)
    default_app = "__idaptive_cybr_user_oidc"
    return {
        "username": username,
        "password": password,
        "mfa_method": mfa_method,
        "interactive_mfa": interactive,
        "identity_url": None,
        "tenant_subdomain": None,
        "identity_application": default_app,
    }


def prompt_mfa_method() -> str:
    methods = SUPPORTED_MFA_METHODS
    default = "email"
    print("\nAvailable MFA methods:")
    for idx, method in enumerate(methods, start=1):
        label = "auto (use Identity profile default)" if method == "auto" else method
        print(f"  {idx}. {label}")
    while True:
        choice = strip_value(input(f"Choose MFA method [{default}]: "))
        if not choice:
            return default
        if choice.isdigit():
            idx = int(choice)
            if 1 <= idx <= len(methods):
                return methods[idx - 1]
        lowered = choice.lower()
        if lowered in methods:
            return lowered
        print("  Invalid selection. Please enter the option number or method name.")


def prompt_yes_no(message: str, *, default: bool) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        answer = strip_value(input(f"{message} {suffix}: "))
        if not answer:
            return default
        lowered = answer.lower()
        if lowered in {"y", "yes"}:
            return True
        if lowered in {"n", "no"}:
            return False
        print("  Please answer with yes or no.")


def prompt_main_action() -> str:
    print()
    return prompt_operation_choice()


def prompt_template_path(default_path: Path, message: str) -> Path:
    prompt_default = str(default_path)
    response = strip_value(input(f"{message} [{prompt_default}]: "))
    selected = Path(response) if response else default_path
    return selected



def prompt_selection_indices(count: int, label: str) -> List[int]:
    if count <= 0:
        return []
    prompt_text = (
        f"Enter {label} numbers to delete (comma separated, ranges like 1-10, 'all' for everything, empty to cancel): "
    )
    while True:
        response = strip_value(input(prompt_text))
        if response is None:
            return []
        lowered = response.lower()
        if lowered == "all":
            return list(range(count))
        tokens: List[int] = []
        for chunk in response.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            if "-" in chunk:
                start_str, end_str = [part.strip() for part in chunk.split("-", 1)]
                start = int(start_str)
                end = int(end_str)
                if start > end:
                    raise ValueError
                tokens.extend(range(start, end + 1))
            else:
                tokens.append(int(chunk))
        indices: Set[int] = set()
        try:
            for token in tokens:
                index = token - 1
                if index < 0 or index >= count:
                    raise ValueError
                indices.add(index)
        except ValueError:
            print(f"  Invalid selection. Please provide numbers between 1 and {count}.")
            continue
        if not indices:
            print("  No valid selections detected. Try again or press Enter to cancel.")
            continue
        return sorted(indices)


def describe_db_secret(secret: Any) -> str:
    secret_name = getattr(secret, "secret_name", None) or getattr(secret, "id", None) or "<unnamed>"
    secret_type = getattr(secret, "secret_type", None)
    store = getattr(getattr(secret, "secret_store", None), "store_type", None)
    suffix = []
    if secret_type:
        suffix.append(str(secret_type))
    if store:
        suffix.append(f"store={store}")
    return f"{secret_name} ({', '.join(suffix)})" if suffix else str(secret_name)


def describe_vm_secret(secret: Any) -> str:
    secret_name = getattr(secret, "secret_name", None) or getattr(secret, "secret_id", None) or "<unnamed>"
    secret_type = getattr(secret, "secret_type", None)
    is_active = getattr(secret, "is_active", None)
    status = "active" if is_active or is_active is None else "disabled"
    details = []
    if secret_type:
        details.append(str(secret_type))
    details.append(status)
    return f"{secret_name} ({', '.join(details)})"


def describe_db_workspace(db_info: Any) -> str:
    name = getattr(db_info, "name", None) or getattr(db_info, "id", None) or "<unnamed>"
    engine = getattr(db_info, "provider_engine", None)
    platform = getattr(db_info, "platform", None)
    parts = [str(name)]
    details = []
    if engine:
        details.append(str(engine))
    if platform:
        details.append(str(platform))
    if details:
        parts.append(f"({', '.join(details)})")
    return " ".join(parts)


def describe_vm_target_set(target: Any) -> str:
    name = getattr(target, "name", None) or "<unnamed>"
    target_type = getattr(target, "type", None)
    return f"{name} ({target_type})" if target_type else str(name)


def prompt_deletion_category(prompt_message: str) -> Optional[str]:
    while True:
        choice = strip_value(input(prompt_message))
        if choice is None or choice.lower() in {"", "cancel", "c", "q", "quit"}:
            return None
        lowered = choice.lower()
        if lowered in {"db", "database"}:
            return "db"
        if lowered in {"vm", "target", "vm_secret"}:
            return "vm"
        if lowered in {"both", "all"}:
            return "both"
        print("  Please enter 'db', 'vm', 'both', or press Enter to cancel.")



def prompt_existing_template(initial_path: Path, message: str) -> Path:
    if initial_path.exists():
        return initial_path
    LOGGER.error("Template file '%s' for %s was not found.", initial_path, message)
    hint = TEMPLATE_FLAG_HINTS.get(message, "the appropriate template flag")
    print_template_hints([message])
    raise SystemExit("Template required for %s. Provide a valid path using %s." % (message, hint))

def ensure_required_templates(action: str, args: argparse.Namespace) -> None:
    requirements = {
        "onboard_db": [("db_template", "DB onboarding template path")],
        "onboard_vm": [("vm_template", "VM onboarding template path")],
        "onboard_both": [
            ("db_template", "DB onboarding template path"),
            ("vm_template", "VM onboarding template path"),
        ],
        "policy_db": [("db_policy_template", "DB access policy template path")],
        "policy_vm": [("vm_policy_template", "VM access policy template path")],
    }
    missing_messages: List[str] = []
    for attr, message in requirements.get(action, []):
        value = getattr(args, attr, None)
        if value is None:
            missing_messages.append(message)
    if missing_messages:
        print_operation_summary()
        print_template_hints(missing_messages)
        required_text = ", ".join(missing_messages)
        raise SystemExit(
            "Operation '%s' requires %s. Provide valid path(s) using the flags shown above." % (
                args.operation,
                required_text,
            )
        )

def ensure_db_aliases(database_secrets: Iterable[DbSecretConfig], databases: Iterable[DatabaseConfig]) -> None:
    defined_aliases = {secret.alias for secret in database_secrets}

    def validate_alias(alias: Optional[str], label: str) -> None:
        if alias and alias not in defined_aliases:
            raise ValueError(f"{label} alias '{alias}' is referenced but not defined as a DB secret.")

    for db in databases:
        validate_alias(db.secret_ref, f"Database '{db.name}' secret")
        for service in db.services:
            validate_alias(
                service.secret_ref,
                f"Database '{db.name}' service '{service.service_name}' secret",
            )


def ensure_vm_aliases(vm_secrets: Iterable[VmSecretConfig], vm_target_sets: Iterable[VmTargetSetConfig]) -> None:
    defined_aliases = {secret.alias for secret in vm_secrets}

    def validate_alias(alias: Optional[str], label: str) -> None:
        if alias and alias not in defined_aliases:
            raise ValueError(f"{label} alias '{alias}' is referenced but not defined as a VM secret.")

    for target in vm_target_sets:
        validate_alias(target.secret_ref, f"Target set '{target.name}' secret")


def parse_db_policy_row(row: Dict[str, str], line_no: int) -> DbPolicyConfig:
    policy_name = require_value(row, "policy_name", line_no)
    rule_name = require_value(row, "rule_name", line_no)
    providers_data = parse_json_required(row.get("providers_data"), "providers_data", line_no)
    connect_as = parse_json_required(row.get("connect_as"), "connect_as", line_no)
    status = parse_rule_status(row.get("status"), line_no)
    description = strip_value(row.get("description"))
    providers_tags = parse_list(row.get("providers_tags"))
    start_date = strip_value(row.get("start_date"))
    end_date = strip_value(row.get("end_date"))
    user_roles = parse_list(row.get("user_roles"))
    user_groups = parse_list(row.get("user_groups"))
    user_users = parse_list(row.get("user_users"))
    full_days = parse_bool(row.get("full_days"))
    days_of_week = parse_days_of_week(row.get("days_of_week"), line_no) if strip_value(row.get("days_of_week")) else []
    hours_from = strip_value(row.get("hours_from"))
    hours_to = strip_value(row.get("hours_to"))
    time_zone = strip_value(row.get("time_zone"))
    grant_access_hours = parse_int(row.get("grant_access_hours"), "grant_access_hours", line_no) if strip_value(
        row.get("grant_access_hours")
    ) else None
    idle_time_minutes = parse_int(row.get("idle_time_minutes"), "idle_time_minutes", line_no) if strip_value(
        row.get("idle_time_minutes")
    ) else None

    if not providers_data:
        raise ValueError("DB access policy must include providers_data.")
    if not connect_as:
        raise ValueError("DB access policy must include connect_as configuration.")

    return DbPolicyConfig(
        policy_name=policy_name,
        description=description,
        status=status,
        start_date=start_date,
        end_date=end_date,
        providers_tags=providers_tags,
        providers_data=providers_data,
        rule_name=rule_name,
        user_roles=user_roles,
        user_groups=user_groups,
        user_users=user_users,
        full_days=full_days,
        days_of_week=days_of_week,
        hours_from=hours_from,
        hours_to=hours_to,
        time_zone=time_zone,
        grant_access_hours=grant_access_hours,
        idle_time_minutes=idle_time_minutes,
        connect_as=connect_as,
        line_number=line_no,
    )


def parse_vm_policy_row(row: Dict[str, str], line_no: int) -> VmPolicyConfig:
    policy_name = require_value(row, "policy_name", line_no)
    rule_name = require_value(row, "rule_name", line_no)
    providers_data = parse_json_required(row.get("providers_data"), "providers_data", line_no)
    connect_as = parse_json_required(row.get("connect_as"), "connect_as", line_no)
    status = parse_rule_status(row.get("status"), line_no)
    description = strip_value(row.get("description"))
    start_date = strip_value(row.get("start_date"))
    end_date = strip_value(row.get("end_date"))
    user_roles = parse_list(row.get("user_roles"))
    user_groups = parse_list(row.get("user_groups"))
    user_users = parse_list(row.get("user_users"))
    full_days = parse_bool(row.get("full_days"))
    days_of_week = parse_days_of_week(row.get("days_of_week"), line_no) if strip_value(row.get("days_of_week")) else []
    hours_from = strip_value(row.get("hours_from"))
    hours_to = strip_value(row.get("hours_to"))
    time_zone = strip_value(row.get("time_zone"))
    grant_access_hours = parse_int(row.get("grant_access_hours"), "grant_access_hours", line_no) if strip_value(
        row.get("grant_access_hours")
    ) else None
    idle_time_minutes = parse_int(row.get("idle_time_minutes"), "idle_time_minutes", line_no) if strip_value(
        row.get("idle_time_minutes")
    ) else None

    if not providers_data:
        raise ValueError("VM access policy must include providers_data.")
    if not connect_as:
        raise ValueError("VM access policy must include connect_as configuration.")

    return VmPolicyConfig(
        policy_name=policy_name,
        description=description,
        status=status,
        start_date=start_date,
        end_date=end_date,
        providers_data=providers_data,
        rule_name=rule_name,
        user_roles=user_roles,
        user_groups=user_groups,
        user_users=user_users,
        full_days=full_days,
        days_of_week=days_of_week,
        hours_from=hours_from,
        hours_to=hours_to,
        time_zone=time_zone,
        grant_access_hours=grant_access_hours,
        idle_time_minutes=idle_time_minutes,
        connect_as=connect_as,
        line_number=line_no,
    )


def load_db_policy_template_csv(path: Path) -> List[DbPolicyConfig]:
    if not path.exists():
        raise FileNotFoundError(f"DB policy template file '{path}' does not exist")
    policies: List[DbPolicyConfig] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "record_type" not in reader.fieldnames:
            raise ValueError("The DB policy CSV must include a 'record_type' header column.")
        for index, row in enumerate(reader, start=2):
            if not row:
                continue
            record_type = strip_value(row.get("record_type"))
            if not record_type:
                continue
            try:
                if record_type.lower() == "db_policy":
                    policies.append(parse_db_policy_row(row, index))
                else:
                    raise ValueError(f"Unsupported record_type '{record_type}' for DB policies")
            except ValueError as exc:
                raise ValueError(f"Error while parsing row {index}: {exc}") from exc
    if not policies:
        raise ValueError("No DB access policies were found in the template.")
    return policies


def load_vm_policy_template_csv(path: Path) -> List[VmPolicyConfig]:
    if not path.exists():
        raise FileNotFoundError(f"VM policy template file '{path}' does not exist")
    policies: List[VmPolicyConfig] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "record_type" not in reader.fieldnames:
            raise ValueError("The VM policy CSV must include a 'record_type' header column.")
        for index, row in enumerate(reader, start=2):
            if not row:
                continue
            record_type = strip_value(row.get("record_type"))
            if not record_type:
                continue
            try:
                if record_type.lower() == "vm_policy":
                    policies.append(parse_vm_policy_row(row, index))
                else:
                    raise ValueError(f"Unsupported record_type '{record_type}' for VM policies")
            except ValueError as exc:
                raise ValueError(f"Error while parsing row {index}: {exc}") from exc
    if not policies:
        raise ValueError("No VM access policies were found in the template.")
    return policies


class PCloudAccountValidator:
    def __init__(self, pcloud_api: ArkPCloudAPI) -> None:
        self._api = pcloud_api
        self._cache: Dict[Tuple[str, str], bool] = {}

    def ensure_exists(self, secret_cfg: Any) -> None:
        safe_name = getattr(secret_cfg, "pcloud_account_safe", None) or getattr(secret_cfg, "pam_safe", None) or ""
        account_name = getattr(secret_cfg, "pcloud_account_name", None) or getattr(secret_cfg, "pam_account_name", None) or ""
        key = (safe_name.lower(), account_name.lower())
        if key in self._cache:
            if not self._cache[key]:
                raise ValueError(
                    f"Privilege Cloud account '{account_name}' in safe '{safe_name}' was not found previously; please verify the CSV entry."
                )
            return

        try:
            exists = self._account_exists(safe_name, account_name)
        except ArkServiceException as exc:
            raise ValueError(f"Unable to validate Privilege Cloud account '{account_name}' in safe '{safe_name}': {exc}") from exc

        self._cache[key] = exists
        if not exists:
            raise ValueError(
                f"Privilege Cloud account '{account_name}' in safe '{safe_name}' was not found or is not accessible with the current credentials."
            )

    def _account_exists(self, safe_name: str, account_name: str) -> bool:
        def match_accounts(pages: Iterable[Any]) -> bool:
            for page in pages:
                for account in getattr(page, "items", []):
                    if getattr(account, "safe_name", None) == safe_name and getattr(account, "name", None) == account_name:
                        return True
            return False

        try:
            if match_accounts(
                self._api.accounts.list_accounts_by(
                    ArkPCloudAccountsFilter(safe_name=safe_name, search=account_name, search_type="contains")
                )
            ):
                return True
        except ArkServiceException as exc:
            LOGGER.warning(
                "Failed to query Privilege Cloud accounts using filtered request for safe '%s': %s. Falling back to full listing.",
                safe_name,
                exc,
            )

        try:
            return match_accounts(self._api.accounts.list_accounts())
        except ArkServiceException as exc:
            raise exc


def build_db_policy_model(cfg: DbPolicyConfig) -> ArkSIADBAddPolicy:
    providers_data = ArkSIADBProvidersData.model_validate(cfg.providers_data)
    connection_info_data = compact_dict(
        {
            "full_days": cfg.full_days,
            "days_of_week": cfg.days_of_week,
            "hours_from": cfg.hours_from,
            "hours_to": cfg.hours_to,
            "time_zone": cfg.time_zone,
            "grant_access": cfg.grant_access_hours,
            "idle_time": cfg.idle_time_minutes,
            "connect_as": cfg.connect_as,
        }
    )
    connection_information = ArkSIADBConnectionInformation.model_validate(connection_info_data)
    user_data = ArkSIAUserData(roles=cfg.user_roles, groups=cfg.user_groups, users=cfg.user_users)
    rule = ArkSIADBAuthorizationRule(rule_name=cfg.rule_name, user_data=user_data, connection_information=connection_information)
    policy_kwargs = compact_dict(
        {
            "policy_name": cfg.policy_name,
            "description": cfg.description,
            "status": cfg.status,
            "start_date": cfg.start_date,
            "end_date": cfg.end_date,
            "providers_tags": cfg.providers_tags,
            "providers_data": providers_data,
            "user_access_rules": [rule],
        }
    )
    return ArkSIADBAddPolicy(**policy_kwargs)


def build_vm_policy_model(cfg: VmPolicyConfig) -> ArkSIAVMAddPolicy:
    connection_info_data = compact_dict(
        {
            "full_days": cfg.full_days,
            "days_of_week": cfg.days_of_week,
            "hours_from": cfg.hours_from,
            "hours_to": cfg.hours_to,
            "time_zone": cfg.time_zone,
            "grant_access": cfg.grant_access_hours,
            "idle_time": cfg.idle_time_minutes,
            "connect_as": cfg.connect_as,
        }
    )
    connection_information = ArkSIAVMConnectionInformation.model_validate(connection_info_data)
    user_data = ArkSIAUserData(roles=cfg.user_roles, groups=cfg.user_groups, users=cfg.user_users)
    rule = ArkSIAVMAuthorizationRule(rule_name=cfg.rule_name, user_data=user_data, connection_information=connection_information)
    policy_kwargs = compact_dict(
        {
            "policy_name": cfg.policy_name,
            "description": cfg.description,
            "status": cfg.status,
            "start_date": cfg.start_date,
            "end_date": cfg.end_date,
            "providers_data": cfg.providers_data,
            "user_access_rules": [rule],
        }
    )
    return ArkSIAVMAddPolicy(**policy_kwargs)


def process_db_policies(sia_api: ArkSIAAPI, configs: List[DbPolicyConfig]) -> List[str]:
    created: List[str] = []
    for cfg in configs:
        try:
            policy_model = build_db_policy_model(cfg)
        except ValidationError as exc:
            raise ValueError(f"Failed to validate DB policy '{cfg.policy_name}' (row {cfg.line_number}): {exc}") from exc
        LOGGER.info("Creating DB access policy '%s'", cfg.policy_name)
        policy = sia_api.policies_db.add_policy(policy_model)
        created.append(policy.policy_name)
    return created


def process_vm_policies(sia_api: ArkSIAAPI, configs: List[VmPolicyConfig]) -> List[str]:
    created: List[str] = []
    for cfg in configs:
        try:
            policy_model = build_vm_policy_model(cfg)
        except ValidationError as exc:
            raise ValueError(f"Failed to validate VM policy '{cfg.policy_name}' (row {cfg.line_number}): {exc}") from exc
        LOGGER.info("Creating VM access policy '%s'", cfg.policy_name)
        policy = sia_api.policies_vm.add_policy(policy_model)
        created.append(policy.policy_name)
    return created


def process_access_policies(
    sia_api: ArkSIAAPI, db_policies: List[DbPolicyConfig], vm_policies: List[VmPolicyConfig]
) -> Tuple[List[str], List[str]]:
    created_db: List[str] = []
    created_vm: List[str] = []
    if db_policies:
        created_db = process_db_policies(sia_api, db_policies)
    if vm_policies:
        created_vm = process_vm_policies(sia_api, vm_policies)
    return created_db, created_vm


def setup_logging(log_dir: Path) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"sia_log_{timestamp}.log"
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    handlers = [
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_path, encoding="utf-8"),
    ]
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", handlers=handlers)
    return log_path


def ensure_db_secret(
    sia_api: ArkSIAAPI,
    cfg: DbSecretConfig,
    reuse_existing: bool,
) -> str:
    try:
        existing = sia_api.secrets_db.list_secrets_by(ArkSIADBSecretsFilter(secret_name=cfg.secret_name))
    except ArkServiceException as exc:
        LOGGER.warning("Unable to check existing DB secrets for '%s': %s", cfg.secret_name, exc)
    else:
        for secret in existing.secrets:
            if secret.secret_name == cfg.secret_name:
                LOGGER.info("Reusing existing DB secret '%s' (%s)", cfg.secret_name, secret.secret_id)
                return secret.secret_id
    LOGGER.info("Creating DB secret '%s'", cfg.secret_name)
    created = sia_api.secrets_db.add_secret(cfg.to_model())
    return created.secret_id


def ensure_vm_secret(
    sia_api: ArkSIAAPI,
    cfg: VmSecretConfig,
    reuse_existing: bool,
) -> str:
    if cfg.secret_name:
        try:
            matches = sia_api.secrets_vm.list_secrets_by(ArkSIAVMSecretsFilter(name=cfg.secret_name))
        except ArkServiceException as exc:
            LOGGER.warning("Unable to check existing VM secrets for '%s': %s", cfg.secret_name, exc)
        else:
            for secret in matches:
                if secret.secret_name == cfg.secret_name:
                    LOGGER.info("Reusing existing VM secret '%s' (%s)", cfg.secret_name, secret.secret_id)
                    return secret.secret_id
    LOGGER.info("Creating VM secret%s", f" '{cfg.secret_name}'" if cfg.secret_name else "")
    created = sia_api.secrets_vm.add_secret(cfg.to_model())
    return created.secret_id


def build_database_model(cfg: DatabaseConfig, db_secret_ids: Dict[str, str]) -> ArkSIADBAddDatabase:
    secret_id = cfg.secret_id
    if cfg.secret_ref:
        secret_id = db_secret_ids[cfg.secret_ref]

    service_models: List[ArkSIADBDatabaseTargetService] = []
    for service_cfg in cfg.services:
        service_secret = service_cfg.secret_id
        if service_cfg.secret_ref:
            service_secret = db_secret_ids[service_cfg.secret_ref]
        service_models.append(
            ArkSIADBDatabaseTargetService(service_name=service_cfg.service_name, port=service_cfg.port, secret_id=service_secret)
        )

    kwargs: Dict[str, Any] = {
        "name": cfg.name,
        "network_name": cfg.network_name,
        "platform": cfg.platform,
        "auth_database": cfg.auth_database,
        "services": service_models,
        "domain": cfg.domain,
        "account": cfg.account,
        "enable_certificate_validation": cfg.enable_certificate_validation,
        "certificate": None,
        "read_write_endpoint": cfg.read_write_endpoint,
        "read_only_endpoint": cfg.read_only_endpoint,
        "port": None,
        "secret_id": secret_id,
        "tags": [ArkSIADBTag(key=t.key, value=t.value) for t in cfg.tags] or None,
        "configured_auth_method_type": cfg.configured_auth_method_type,
        "region": cfg.region,
        "provider_engine": cfg.provider_engine,
    }

    if cfg.domain_controller:
        dc_payload = cfg.domain_controller.model_dump(exclude_none=True)
        if "name" in dc_payload:
            kwargs["domain_controller_name"] = dc_payload["name"]
        if "netbios" in dc_payload:
            kwargs["domain_controller_netbios"] = dc_payload["netbios"]
        if "use_ldaps" in dc_payload:
            kwargs["domain_controller_use_ldaps"] = dc_payload["use_ldaps"]
        if "enable_certificate_validation" in dc_payload:
            kwargs["domain_controller_enable_certificate_validation"] = dc_payload["enable_certificate_validation"]
        if "ldaps_certificate" in dc_payload:
            kwargs["domain_controller_ldaps_certificate"] = dc_payload["ldaps_certificate"]

    return ArkSIADBAddDatabase(**{k: v for k, v in kwargs.items() if v is not None})


def build_target_set_model(cfg: VmTargetSetConfig, vm_secret_ids: Dict[str, str]) -> ArkSIAAddTargetSet:
    secret_id = cfg.secret_id
    if cfg.secret_ref:
        secret_id = vm_secret_ids[cfg.secret_ref]
    return ArkSIAAddTargetSet(
        name=cfg.name,
        description=cfg.description,
        provision_format=cfg.provision_format,
        enable_certificate_validation=cfg.enable_certificate_validation,
        secret_type=cfg.secret_type,
        secret_id=secret_id,
        type=cfg.type,
    )


def process_db_secrets(
    sia_api: ArkSIAAPI,
    configs: List[DbSecretConfig],
    reuse_existing: bool,
    required_aliases: Optional[Set[str]] = None,
    pcloud_validator: Optional[PCloudAccountValidator] = None,
) -> Tuple[Dict[str, str], Set[str]]:
    secret_ids: Dict[str, str] = {}
    skipped_aliases: Set[str] = set()
    for cfg in configs:
        if required_aliases and cfg.alias not in required_aliases:
            continue
        if pcloud_validator and (cfg.pam_safe or cfg.pam_account_name):
            try:
                pcloud_validator.ensure_exists(cfg)
            except (ValueError, ArkServiceException) as exc:
                LOGGER.warning(
                    "Skipping DB secret alias '%s' due to Privilege Cloud validation failure: %s",
                    cfg.alias,
                    exc,
                )
                skipped_aliases.add(cfg.alias)
                continue
        try:
            secret_ids[cfg.alias] = ensure_db_secret(sia_api, cfg, reuse_existing)
        except ArkServiceException as exc:
            LOGGER.warning(
                "Skipping DB secret alias '%s': unable to ensure secret in SIA (%s)",
                cfg.alias,
                exc,
            )
            skipped_aliases.add(cfg.alias)
            continue
    if required_aliases:
        missing_aliases = required_aliases - set(secret_ids) - skipped_aliases
        if missing_aliases:
            raise ValueError(
                "DB secret definitions missing for aliases: %s" % ", ".join(sorted(missing_aliases))
            )
    return secret_ids, skipped_aliases


def process_vm_secrets(
    sia_api: ArkSIAAPI,
    configs: List[VmSecretConfig],
    reuse_existing: bool,
    pcloud_validator: Optional[PCloudAccountValidator] = None,
    required_aliases: Optional[Set[str]] = None,
) -> Tuple[Dict[str, str], Set[str]]:
    secret_ids: Dict[str, str] = {}
    skipped_aliases: Set[str] = set()
    for cfg in configs:
        if required_aliases and cfg.alias not in required_aliases:
            continue
        if pcloud_validator and cfg.secret_type == ArkSIAVMSecretType.PCloudAccount:
            try:
                pcloud_validator.ensure_exists(cfg)
            except (ValueError, ArkServiceException) as exc:
                LOGGER.warning(
                    "Skipping VM secret alias '%s' due to Privilege Cloud validation failure: %s",
                    cfg.alias,
                    exc,
                )
                skipped_aliases.add(cfg.alias)
                continue
        try:
            secret_ids[cfg.alias] = ensure_vm_secret(sia_api, cfg, reuse_existing)
        except ArkServiceException as exc:
            LOGGER.warning("Skipping VM secret alias '%s': unable to ensure secret in SIA (%s)", cfg.alias, exc)
            skipped_aliases.add(cfg.alias)
            continue
    if required_aliases:
        missing_aliases = required_aliases - set(secret_ids) - skipped_aliases
        if missing_aliases:
            raise ValueError(
                "VM secret definitions missing for aliases: %s" % ", ".join(sorted(missing_aliases))
            )
    return secret_ids, skipped_aliases


def collect_db_secret_requirements(databases: Iterable[DatabaseConfig]) -> Tuple[Set[str], Set[str]]:
    alias_refs: Set[str] = set()
    secret_ids: Set[str] = set()
    for db in databases:
        if db.secret_ref:
            alias_refs.add(db.secret_ref)
        if db.secret_id:
            secret_ids.add(db.secret_id)
        for service in db.services:
            if service.secret_ref:
                alias_refs.add(service.secret_ref)
            if service.secret_id:
                secret_ids.add(service.secret_id)
    return alias_refs, secret_ids


def collect_vm_secret_requirements(vm_target_sets: Iterable[VmTargetSetConfig]) -> Tuple[Set[str], Set[str]]:
    alias_refs: Set[str] = set()
    secret_ids: Set[str] = set()
    for target in vm_target_sets:
        if target.secret_ref:
            alias_refs.add(target.secret_ref)
        if target.secret_id:
            secret_ids.add(target.secret_id)
    return alias_refs, secret_ids


def verify_db_secret_ids_exist(sia_api: ArkSIAAPI, secret_ids: Set[str]) -> None:
    if not secret_ids:
        return
    missing: List[str] = []
    for secret_id in secret_ids:
        try:
            sia_api.secrets_db.secret(ArkSIADBGetSecret(secret_id=secret_id))
        except ArkServiceException as exc:
            missing.append(f"{secret_id} ({exc})")
    if missing:
        raise ValueError(
            "The following DB secret IDs were not found in SIA: %s" % ", ".join(missing)
        )


def verify_vm_secret_ids_exist(sia_api: ArkSIAAPI, secret_ids: Set[str]) -> None:
    if not secret_ids:
        return
    missing: List[str] = []
    for secret_id in secret_ids:
        try:
            sia_api.secrets_vm.secret(ArkSIAVMGetSecret(secret_id=secret_id))
        except ArkServiceException as exc:
            missing.append(f"{secret_id} ({exc})")
    if missing:
        raise ValueError(
            "The following VM secret IDs were not found in SIA: %s" % ", ".join(missing)
        )


def process_databases(
    sia_api: ArkSIAAPI,
    configs: List[DatabaseConfig],
    db_secret_ids: Dict[str, str],
    reuse_existing: bool,
) -> List[str]:
    created: List[str] = []
    for cfg in configs:
        if cfg.secret_ref and cfg.secret_ref not in db_secret_ids:
            LOGGER.warning(
                "Skipping database '%s' because DB secret alias '%s' was not created.",
                cfg.name,
                cfg.secret_ref,
            )
            continue
        missing_service_alias = False
        for service in cfg.services:
            if service.secret_ref and service.secret_ref not in db_secret_ids:
                LOGGER.warning(
                    "Skipping database '%s' because service '%s' depends on missing DB secret alias '%s'.",
                    cfg.name,
                    service.service_name,
                    service.secret_ref,
                )
                missing_service_alias = True
                break
        if missing_service_alias:
            continue
        if reuse_existing:
            try:
                existing = sia_api.workspace_db.list_databases_by(ArkSIADBDatabasesFilter(name=cfg.name))
            except ArkServiceException as exc:
                LOGGER.warning("Unable to check existing databases for '%s': %s", cfg.name, exc)
            else:
                if existing.items:
                    LOGGER.info("Database '%s' already exists (id=%s), skipping creation", cfg.name, existing.items[0].id)
                    continue
        try:
            model = build_database_model(cfg, db_secret_ids)
        except (ValidationError, ValueError) as exc:
            LOGGER.warning("Skipping database '%s': %s", cfg.name, exc)
            continue
        LOGGER.info("Adding SIA database '%s'", cfg.name)
        try:
            sia_api.workspace_db.add_database(model)
        except ArkServiceException as exc:
            LOGGER.error("Failed to add SIA database '%s': %s", cfg.name, exc)
            continue
        created.append(cfg.name)
    return created


def process_target_sets(
    sia_api: ArkSIAAPI,
    configs: List[VmTargetSetConfig],
    vm_secret_ids: Dict[str, str],
    reuse_existing: bool,
    skipped_aliases: Set[str],
) -> List[str]:
    created: List[str] = []
    for cfg in configs:
        if cfg.secret_ref and cfg.secret_ref in skipped_aliases:
            LOGGER.warning(
                "Skipping target set '%s' because VM secret alias '%s' was previously skipped.",
                cfg.name,
                cfg.secret_ref,
            )
            continue
        if cfg.secret_ref and cfg.secret_ref not in vm_secret_ids:
            LOGGER.warning(
                "Skipping target set '%s' because VM secret alias '%s' is unavailable.",
                cfg.name,
                cfg.secret_ref,
            )
            continue
        if reuse_existing:
            try:
                existing = sia_api.workspace_target_sets.list_target_sets_by(ArkSIATargetSetsFilter(name=cfg.name))
            except ArkServiceException as exc:
                LOGGER.warning("Unable to check existing target sets for '%s': %s", cfg.name, exc)
            else:
                if existing:
                    LOGGER.info("Target set '%s' already exists, skipping creation", cfg.name)
                    continue
        model = build_target_set_model(cfg, vm_secret_ids)
        LOGGER.info("Adding SIA VM target set '%s'", cfg.name)
        sia_api.workspace_target_sets.add_target_set(model)
        created.append(cfg.name)
    return created




def run_db_onboarding(
    sia_api: ArkSIAAPI,
    args: argparse.Namespace,
    reuse_existing: bool,
    isp_auth: ArkISPAuth,
) -> Tuple[Dict[str, str], Set[str], List[str]]:
    db_template_path = prompt_existing_template(args.db_template, "DB onboarding template path")
    LOGGER.info("Using DB onboarding template: %s", db_template_path)
    db_template = load_db_template_csv(db_template_path)
    ensure_db_aliases(db_template.database_secrets, db_template.databases)

    required_aliases, required_secret_ids = collect_db_secret_requirements(db_template.databases)
    required_aliases = {alias for alias in required_aliases if alias}
    active_aliases = required_aliases if required_aliases else None

    pcloud_validator: Optional[PCloudAccountValidator] = None
    if any(
        (active_aliases is None or cfg.alias in active_aliases)
        and (
            cfg.secret_type == ArkSIADBSecretType.CyberArkPAM
            or cfg.store_type == ArkSIADBStoreType.PAM
            or cfg.pam_safe
            or cfg.pam_account_name
        )
        for cfg in db_template.database_secrets
    ):
        pcloud_validator = PCloudAccountValidator(ArkPCloudAPI(isp_auth))

    db_secret_ids, skipped_db_aliases = process_db_secrets(
        sia_api,
        db_template.database_secrets,
        reuse_existing,
        required_aliases=active_aliases,
        pcloud_validator=pcloud_validator,
    )
    verify_db_secret_ids_exist(sia_api, required_secret_ids)
    created_databases = process_databases(sia_api, db_template.databases, db_secret_ids, reuse_existing)
    return db_secret_ids, skipped_db_aliases, created_databases


def run_vm_onboarding(
    sia_api: ArkSIAAPI,
    args: argparse.Namespace,
    reuse_existing: bool,
    isp_auth: ArkISPAuth,
) -> Tuple[Dict[str, str], Set[str], List[str]]:
    vm_template_path = prompt_existing_template(args.vm_template, "VM onboarding template path")
    LOGGER.info("Using VM onboarding template: %s", vm_template_path)
    vm_template = load_vm_template_csv(vm_template_path)
    ensure_vm_aliases(vm_template.vm_secrets, vm_template.vm_target_sets)

    required_aliases, required_secret_ids = collect_vm_secret_requirements(vm_template.vm_target_sets)
    required_aliases = {alias for alias in required_aliases if alias}
    active_aliases = required_aliases if required_aliases else None

    pcloud_validator: Optional[PCloudAccountValidator] = None
    if any(
        (active_aliases is None or secret.alias in active_aliases)
        and secret.secret_type == ArkSIAVMSecretType.PCloudAccount
        for secret in vm_template.vm_secrets
    ):
        pcloud_validator = PCloudAccountValidator(ArkPCloudAPI(isp_auth))
    vm_secret_ids, skipped_vm_aliases = process_vm_secrets(
        sia_api,
        vm_template.vm_secrets,
        reuse_existing,
        pcloud_validator,
        required_aliases=active_aliases,
    )
    verify_vm_secret_ids_exist(sia_api, required_secret_ids)
    created_target_sets = process_target_sets(
        sia_api,
        vm_template.vm_target_sets,
        vm_secret_ids,
        reuse_existing,
        skipped_vm_aliases,
    )
    return vm_secret_ids, skipped_vm_aliases, created_target_sets



def delete_db_secrets(sia_api: ArkSIAAPI) -> None:
    try:
        metadata = sia_api.secrets_db.list_secrets()
        secrets = getattr(metadata, "secrets", [])
    except ArkServiceException as exc:
        LOGGER.error("Unable to list DB secrets: %s", exc)
        return
    if not secrets:
        LOGGER.info("No DB secrets available for deletion.")
        return
    print()
    print("DB secrets available:")
    for idx, secret in enumerate(secrets, start=1):
        print(f"  {idx}. {describe_db_secret(secret)}")
    indices = prompt_selection_indices(len(secrets), "DB secret")
    if not indices:
        LOGGER.info("DB secret deletion cancelled.")
        return
    selected = [secrets[i] for i in indices]
    names = ", ".join(str(getattr(item, "secret_name", getattr(item, "secret_id", "<unnamed>"))) for item in selected)
    if not prompt_yes_no(f"Delete {len(selected)} DB secret(s): {names}?", default=False):
        LOGGER.info("DB secret deletion cancelled by user.")
        return
    for item in selected:
        secret_id = getattr(item, "secret_id", None)
        secret_name = getattr(item, "secret_name", None) or secret_id
        if not secret_id:
            LOGGER.warning("Skipping DB secret '%s' because no secret_id was found.", secret_name)
            continue
        try:
            sia_api.secrets_db.delete_secret(ArkSIADBDeleteSecret(secret_id=secret_id))
            LOGGER.info("Deleted DB secret '%s'", secret_name)
        except ArkServiceException as exc:
            LOGGER.error("Failed to delete DB secret '%s': %s", secret_name, exc)



def delete_vm_secrets(sia_api: ArkSIAAPI) -> None:
    try:
        secrets = sia_api.secrets_vm.list_secrets()
    except ArkServiceException as exc:
        LOGGER.error("Unable to list VM secrets: %s", exc)
        return
    if not secrets:
        LOGGER.info("No VM secrets available for deletion.")
        return
    print()
    print("VM secrets available:")
    for idx, secret in enumerate(secrets, start=1):
        print(f"  {idx}. {describe_vm_secret(secret)}")
    indices = prompt_selection_indices(len(secrets), "VM secret")
    if not indices:
        LOGGER.info("VM secret deletion cancelled.")
        return
    selected = [secrets[i] for i in indices]
    names = ", ".join(str(getattr(item, "secret_name", getattr(item, "secret_id", "<unnamed>"))) for item in selected)
    if not prompt_yes_no(f"Delete {len(selected)} VM secret(s): {names}?", default=False):
        LOGGER.info("VM secret deletion cancelled by user.")
        return
    for item in selected:
        secret_id = getattr(item, "secret_id", None)
        secret_name = getattr(item, "secret_name", None) or secret_id
        if not secret_id:
            LOGGER.warning("Skipping VM secret '%s' because no secret_id was found.", secret_name)
            continue
        try:
            sia_api.secrets_vm.delete_secret(ArkSIAVMDeleteSecret(secret_id=secret_id))
            LOGGER.info("Deleted VM secret '%s'", secret_name)
        except ArkServiceException as exc:
            LOGGER.error("Failed to delete VM secret '%s': %s", secret_name, exc)



def handle_delete_strong_accounts(sia_api: ArkSIAAPI) -> None:
    choice = prompt_deletion_category("Delete which strong accounts? [db/vm/both/cancel]: ")
    if choice is None:
        LOGGER.info("Strong account deletion cancelled.")
        return
    if choice in {"db", "both"}:
        delete_db_secrets(sia_api)
    if choice in {"vm", "both"}:
        delete_vm_secrets(sia_api)



def delete_db_workspaces(sia_api: ArkSIAAPI) -> None:
    try:
        databases = sia_api.workspace_db.list_databases().items
    except ArkServiceException as exc:
        LOGGER.error("Unable to list DB workspaces: %s", exc)
        return
    if not databases:
        LOGGER.info("No DB workspaces available for deletion.")
        return
    print()
    print("DB workspaces available:")
    for idx, db_info in enumerate(databases, start=1):
        print(f"  {idx}. {describe_db_workspace(db_info)}")
    indices = prompt_selection_indices(len(databases), "DB workspace")
    if not indices:
        LOGGER.info("DB workspace deletion cancelled.")
        return
    selected = [databases[i] for i in indices]
    names = ", ".join(str(getattr(item, "name", getattr(item, "id", "<unnamed>"))) for item in selected)
    if not prompt_yes_no(f"Delete {len(selected)} DB workspace(s): {names}?", default=False):
        LOGGER.info("DB workspace deletion cancelled by user.")
        return
    for item in selected:
        workspace_id = getattr(item, "id", None)
        name = getattr(item, "name", None) or workspace_id
        if not workspace_id:
            LOGGER.warning("Skipping DB workspace '%s' because no id was found.", name)
            continue
        try:
            sia_api.workspace_db.delete_database(ArkSIADBDeleteDatabase(id=workspace_id))
            LOGGER.info("Deleted DB workspace '%s'", name)
        except ArkServiceException as exc:
            LOGGER.error("Failed to delete DB workspace '%s': %s", name, exc)



def delete_vm_target_sets(sia_api: ArkSIAAPI) -> None:
    try:
        target_sets = sia_api.workspace_target_sets.list_target_sets()
    except ArkServiceException as exc:
        LOGGER.error("Unable to list VM target sets: %s", exc)
        return
    if not target_sets:
        LOGGER.info("No VM target sets available for deletion.")
        return
    print()
    print("VM target sets available:")
    for idx, target in enumerate(target_sets, start=1):
        print(f"  {idx}. {describe_vm_target_set(target)}")
    indices = prompt_selection_indices(len(target_sets), "VM target set")
    if not indices:
        LOGGER.info("VM target set deletion cancelled.")
        return
    selected = [target_sets[i] for i in indices]
    names = ", ".join(str(getattr(item, "name", "<unnamed>")) for item in selected)
    if not prompt_yes_no(f"Delete {len(selected)} VM target set(s): {names}?", default=False):
        LOGGER.info("VM target set deletion cancelled by user.")
        return
    for item in selected:
        name = getattr(item, "name", None)
        if not name:
            LOGGER.warning("Skipping a VM target set because the name could not be determined.")
            continue
        try:
            sia_api.workspace_target_sets.delete_target_set(ArkSIADeleteTargetSet(name=name))
            LOGGER.info("Deleted VM target set '%s'", name)
        except ArkServiceException as exc:
            LOGGER.error("Failed to delete VM target set '%s': %s", name, exc)



def handle_delete_workspaces(sia_api: ArkSIAAPI) -> None:
    choice = prompt_deletion_category("Delete which workspace type? [db/vm/both/cancel]: ")
    if choice is None:
        LOGGER.info("Workspace deletion cancelled.")
        return
    if choice in {"db", "both"}:
        delete_db_workspaces(sia_api)
    if choice in {"vm", "both"}:
        delete_vm_target_sets(sia_api)

def authenticate_identity(auth: ArkISPAuth, inputs: Dict[str, Any], force_login: bool) -> None:
    username = inputs["username"]
    secret = ArkSecret(secret=inputs["password"])

    method = inputs.get("mfa_method") or "email"
    interactive = inputs.get("interactive_mfa")
    if interactive is None:
        interactive = True

    method_settings = IdentityArkAuthMethodSettings(
        identity_mfa_method="" if method == "auto" else method,
        identity_mfa_interactive=interactive,
        identity_url=inputs["identity_url"],
        identity_tenant_subdomain=inputs["tenant_subdomain"],
        identity_application=inputs["identity_application"],
    )
    profile = ArkAuthProfile(
        username=username,
        auth_method=ArkAuthMethod.Identity,
        auth_method_settings=method_settings,
    )
    LOGGER.info("Authenticating to Identity as %s using MFA method '%s'", username, method)
    auth.authenticate(auth_profile=profile, secret=secret, force=force_login, refresh_auth=True)


def main() -> None:
    args = parse_args()
    log_path = setup_logging(args.log_dir)
    LOGGER.info("Execution log file: %s", log_path)
    ArkSystemConfig.disable_verbose_logging()

    provided_operation = args.operation
    operation_arg = provided_operation.lower()
    action = OPERATION_ALIASES.get(operation_arg)
    if action is None:
        print_operation_summary()
        raise SystemExit("Unsupported operation '%s'." % args.operation)
    if action in {"onboard_db", "onboard_vm"}:
        action = prompt_scoped_operation(action)
    args.operation = action

    if action not in {"onboard_db", "onboard_vm"}:
        show_action_hints(action)
    validate_template_args(args, action)
    ensure_required_templates(action, args)

    identity_inputs = prompt_identity_inputs()

    isp_auth = ArkISPAuth()
    try:
        authenticate_identity(isp_auth, identity_inputs, force_login=True)
    except ArkAuthException as exc:
        raise SystemExit(f"Authentication failed: {exc}") from exc

    sia_api = ArkSIAAPI(isp_auth)

    pending_action = action
    while True:
        if pending_action is None:
            if not sys.stdin.isatty():
                raise SystemExit("No operation specified and unable to prompt interactively.")
            pending_action = prompt_main_action()

        performed = False

        if pending_action == "onboard_both":
            reuse_existing = prompt_yes_no("\nReuse existing SIA objects when matches are found?", default=True)
            db_secret_ids, skipped_db_aliases, created_databases = run_db_onboarding(
                sia_api,
                args,
                reuse_existing,
                isp_auth,
            )
            LOGGER.info("Database / Strong accounts onboarding finished.")
            if db_secret_ids:
                LOGGER.info("DB secrets loaded: %s", ", ".join(f"{alias}={sid}" for alias, sid in db_secret_ids.items()))
            if skipped_db_aliases:
                LOGGER.warning("DB secrets skipped (not created): %s", ", ".join(sorted(skipped_db_aliases)))
            if created_databases:
                LOGGER.info("Databases created: %s", ", ".join(created_databases))
            if not created_databases:
                LOGGER.info("No new databases were created.")

            vm_secret_ids, skipped_vm_aliases, created_target_sets = run_vm_onboarding(
                sia_api, args, reuse_existing, isp_auth
            )
            LOGGER.info("VM onboarding finished.")
            if vm_secret_ids:
                LOGGER.info("VM secrets loaded: %s", ", ".join(f"{alias}={sid}" for alias, sid in vm_secret_ids.items()))
            if skipped_vm_aliases:
                LOGGER.warning("VM secrets skipped (not created): %s", ", ".join(sorted(skipped_vm_aliases)))
            if created_target_sets:
                LOGGER.info("Target sets created: %s", ", ".join(created_target_sets))
            if not created_target_sets:
                LOGGER.info("No new target sets were created.")
            performed = True

        elif pending_action == "onboard_db":
            reuse_existing = prompt_yes_no("\nReuse existing SIA objects when matches are found?", default=True)
            db_secret_ids, skipped_db_aliases, created_databases = run_db_onboarding(
                sia_api,
                args,
                reuse_existing,
                isp_auth,
            )
            LOGGER.info("Database onboarding finished.")
            if db_secret_ids:
                LOGGER.info("DB secrets loaded: %s", ", ".join(f"{alias}={sid}" for alias, sid in db_secret_ids.items()))
            if skipped_db_aliases:
                LOGGER.warning("DB secrets skipped (not created): %s", ", ".join(sorted(skipped_db_aliases)))
            if created_databases:
                LOGGER.info("Databases created: %s", ", ".join(created_databases))
            if not created_databases:
                LOGGER.info("No new databases were created.")
            performed = True

        elif pending_action == "onboard_vm":
            reuse_existing = prompt_yes_no("\nReuse existing SIA objects when matches are found?", default=True)
            vm_secret_ids, skipped_vm_aliases, created_target_sets = run_vm_onboarding(
                sia_api, args, reuse_existing, isp_auth
            )
            LOGGER.info("VM onboarding finished.")
            if vm_secret_ids:
                LOGGER.info("VM secrets loaded: %s", ", ".join(f"{alias}={sid}" for alias, sid in vm_secret_ids.items()))
            if skipped_vm_aliases:
                LOGGER.warning("VM secrets skipped (not created): %s", ", ".join(sorted(skipped_vm_aliases)))
            if created_target_sets:
                LOGGER.info("Target sets created: %s", ", ".join(created_target_sets))
            if not created_target_sets:
                LOGGER.info("No new target sets were created.")
            performed = True

        elif pending_action == "policy":
            process_db_policies_flag = prompt_yes_no("Process DB access policy template?", default=True)
            process_vm_policies_flag = prompt_yes_no("Process VM access policy template?", default=True)
            if not process_db_policies_flag and not process_vm_policies_flag:
                LOGGER.info("No access policy templates selected. Nothing to do.")
            else:
                db_policies: List[DbPolicyConfig] = []
                if process_db_policies_flag:
                    db_policy_template_path = prompt_existing_template(args.db_policy_template, "DB access policy template path")
                    LOGGER.info("Using DB access policy template: %s", db_policy_template_path)
                    db_policies = load_db_policy_template_csv(db_policy_template_path)

                vm_policies: List[VmPolicyConfig] = []
                if process_vm_policies_flag:
                    vm_policy_template_path = prompt_existing_template(args.vm_policy_template, "VM access policy template path")
                    LOGGER.info("Using VM access policy template: %s", vm_policy_template_path)
                    vm_policies = load_vm_policy_template_csv(vm_policy_template_path)

                created_db_policies, created_vm_policies = process_access_policies(sia_api, db_policies, vm_policies)
                if created_db_policies:
                    LOGGER.info("DB policies created: %s", ", ".join(created_db_policies))
                if created_vm_policies:
                    LOGGER.info("VM policies created: %s", ", ".join(created_vm_policies))
                if created_db_policies or created_vm_policies:
                    performed = True
                else:
                    LOGGER.info("No new access policies were created.")

        elif pending_action == "policy_db":
            db_policy_template_path = prompt_existing_template(args.db_policy_template, "DB access policy template path")
            LOGGER.info("Using DB access policy template: %s", db_policy_template_path)
            db_policies = load_db_policy_template_csv(db_policy_template_path)
            created_db_policies = process_db_policies(sia_api, db_policies)
            if created_db_policies:
                LOGGER.info("DB policies created: %s", ", ".join(created_db_policies))
                performed = True
            else:
                LOGGER.info("No new DB access policies were created.")

        elif pending_action == "policy_vm":
            vm_policy_template_path = prompt_existing_template(args.vm_policy_template, "VM access policy template path")
            LOGGER.info("Using VM access policy template: %s", vm_policy_template_path)
            vm_policies = load_vm_policy_template_csv(vm_policy_template_path)
            created_vm_policies = process_vm_policies(sia_api, vm_policies)
            if created_vm_policies:
                LOGGER.info("VM policies created: %s", ", ".join(created_vm_policies))
                performed = True
            else:
                LOGGER.info("No new VM access policies were created.")

        elif pending_action == "delete_secrets":
            handle_delete_strong_accounts(sia_api)
            performed = True
        elif pending_action == "delete_workspaces":
            handle_delete_workspaces(sia_api)
            performed = True
        elif pending_action == "delete_db_workspaces":
            delete_db_workspaces(sia_api)
            performed = True
        elif pending_action == "delete_vm_workspaces":
            delete_vm_target_sets(sia_api)
            performed = True
        elif pending_action == "delete_db_secrets":
            delete_db_secrets(sia_api)
            performed = True
        elif pending_action == "delete_vm_secrets":
            delete_vm_secrets(sia_api)
            performed = True
        else:
            LOGGER.error("Unrecognized action '%s'.", pending_action)

        if performed:
            break

        LOGGER.info("No operations were performed for action '%s'. Please select another option.", pending_action)
        if not sys.stdin.isatty():
            raise SystemExit("No work performed and unable to prompt for a new action in non-interactive mode.")
        pending_action = None

    LOGGER.info("All tasks completed successfully.")


if __name__ == "__main__":
    try:
        main()
    except (ArkServiceException, ValueError, FileNotFoundError) as error:
        raise SystemExit(f"Error: {error}") from error
